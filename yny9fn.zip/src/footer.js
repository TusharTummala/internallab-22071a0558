import React from "react";
import "./footer.css";
const Footer = () => (
  <footer>
    <p>&copy; 2023 Tushar's website 22071A0558</p>
  </footer>
);

export default Footer;
