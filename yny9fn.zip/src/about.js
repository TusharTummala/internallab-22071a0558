import React from "react";

const About = () => (
  <div>
    <h1>About Us</h1>
    <p>
      We are committed to providing the best products and services that you
      deserve.
    </p>
  </div>
);

export default About;
