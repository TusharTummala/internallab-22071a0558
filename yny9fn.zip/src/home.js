import React from "react";
import "./home.css";
const Home = () => (
  <div>
    <h1>Welcome to our Zoop Site!</h1>
    <p>Shop the best products at the best prices.</p>
  </div>
);

export default Home;
